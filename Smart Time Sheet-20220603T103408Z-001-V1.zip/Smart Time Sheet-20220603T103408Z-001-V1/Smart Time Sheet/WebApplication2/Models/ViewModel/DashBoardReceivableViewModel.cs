﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class DashBoardReceivableViewModel
    {
        public string InvoiceNo { get; set; }
        public string InvoiceDate { get; set; }
        public string Company_Name { get; set; }
        public string DueDate { get; set; }

        public string InvoiceNum { get; set; }
        public string InvoiceType { get; set; }

    }
}