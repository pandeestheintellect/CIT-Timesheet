﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class DashBoardHREmpViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string RefNo { get; set; }
        public string ExpiryType { get; set; }
        public string DateofExpiry { get; set; }
        

    }
}