﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class DashBoardCompanyViewModel
    {
        public string Company_Name { get; set; }
        public string Cert_License_Name { get; set; }
        public string Issue_Date { get; set; }
        public string Expiry_Date { get; set; }


    }
}