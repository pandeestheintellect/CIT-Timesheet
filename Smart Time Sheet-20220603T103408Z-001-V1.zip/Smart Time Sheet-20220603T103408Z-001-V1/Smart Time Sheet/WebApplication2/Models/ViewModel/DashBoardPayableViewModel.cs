﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class DashBoardPayableViewModel
    {
        public string PoRefNum { get; set; }
        public string PoDate { get; set; }
        public string Company_Name { get; set; }


    }
}