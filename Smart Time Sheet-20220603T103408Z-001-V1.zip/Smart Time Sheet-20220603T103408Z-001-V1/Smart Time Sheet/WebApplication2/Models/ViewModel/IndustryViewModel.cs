﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class IndustryViewModel
    {
        public int Id { get; set; }
        public string Industry_Code { get; set; }
        public string Industry_Title { get; set; }
    }
}