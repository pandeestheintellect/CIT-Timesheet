﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class DashBoardSVManDTTRViewModel
    {
        public string ProjectTitle { get; set; }
        public string LocationOfWork { get; set; }
        public string RepDate { get; set; }


    }
}