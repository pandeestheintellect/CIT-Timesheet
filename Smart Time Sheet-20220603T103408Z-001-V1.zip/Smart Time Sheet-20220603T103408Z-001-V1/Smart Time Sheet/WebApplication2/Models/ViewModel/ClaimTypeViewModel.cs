﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eng360Web.Models.ViewModel
{
    public class ClaimTypeViewModel
    {
        public int ClaimTypeID { get; set; }
        public string ClaimType { get; set; }
        
        
    }
}